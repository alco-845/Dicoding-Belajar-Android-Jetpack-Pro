package com.alcorp.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}