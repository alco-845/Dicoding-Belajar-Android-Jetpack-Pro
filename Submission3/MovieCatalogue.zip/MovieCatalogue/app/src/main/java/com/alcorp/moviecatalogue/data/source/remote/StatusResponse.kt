package com.alcorp.moviecatalogue.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}